import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Navbar from '../components/Navbar';
import ManagerSidebar from './ManagerSidebar';

const LeaveManager = () => {
  const [leaves, setLeaves] = useState([]);
  const [loading, setLoading] = useState(true);
  const token = localStorage.getItem('token');

  const parseJwt = (token) => {
    try {
      return JSON.parse(atob(token.split('.')[1]));
    } catch (e) {
      return null;
    }
  };

  const fetchLeaves = async (managerEmpId) => {
    try {
      const response = await axios.get(`http://localhost:9000/leave/teamLeaves/${managerEmpId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setLeaves(response.data);
    } catch (error) {
      console.error('Error fetching leave requests:', error);
    } finally {
      setLoading(false);
    }
  };

  const getManagerEmpId = async () => {
    const tokenData = parseJwt(token);
    const username = tokenData?.sub;

    if (!username) {
      console.error('Invalid token');
      setLoading(false);
      return;
    }

    try {
      const response = await axios.get('http://localhost:9000/employee/viewAllEmployees', {
        headers: { Authorization: `Bearer ${token}` },
      });

      const employee = response.data.find((e) => e.empName.toLowerCase() === username.toLowerCase());

      if (!employee) {
        console.error('Manager not found with username:', username);
        setLoading(false);
        return;
      }

      fetchLeaves(employee.empId);
    } catch (error) {
      console.error('Error fetching manager employee ID:', error);
      setLoading(false);
    }
  };

  const handleAction = async (leaveId, action) => {
    try {
      const url = `http://localhost:9000/leave/${action}Leave/${leaveId}`;
      await axios.put(url, {}, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setLeaves((prev) =>
        prev.map((l) =>
          l.leaveId === leaveId ? { ...l, status: action === 'approve' ? 'APPROVED' : 'REJECTED' } : l
        )
      );
    } catch (error) {
      console.error(`Error while trying to ${action} leave:`, error);
    }
  };

  useEffect(() => {
    getManagerEmpId();
  }, []);

  const renderTable = (title, data, showActions = false) => (
    <>
      <h3 className="text-xl font-semibold text-blue-800 my-4">{title}</h3>
      <div className="overflow-x-auto shadow rounded mb-8">
        <table className="min-w-full bg-white divide-y divide-gray-200 text-sm">
          <thead className="bg-blue-500 text-white">
            <tr>
              <th className="px-4 py-2 text-left">Leave ID</th>
              <th className="px-4 py-2 text-left">Employee Name</th>
              <th className="px-4 py-2 text-left">Start Date</th>
              <th className="px-4 py-2 text-left">End Date</th>
              <th className="px-4 py-2 text-left">Status</th>
              {showActions && <th className="px-4 py-2 text-left">Actions</th>}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {data.map((leave) => (
              <tr key={leave.leaveId} className="hover:bg-gray-50">
                <td className="px-4 py-2">{leave.leaveId}</td>
                <td className="px-4 py-2">{leave.employee?.empName || 'Unknown'}</td>
                <td className="px-4 py-2">{leave.startDate}</td>
                <td className="px-4 py-2">{leave.endDate}</td>
                <td className="px-4 py-2">{leave.status}</td>
                {showActions && (
                  <td className="px-4 py-2 space-x-2">
                    <button
                      onClick={() => handleAction(leave.leaveId, 'approve')}
                      className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded"
                    >
                      Approve
                    </button>
                    <button
                      onClick={() => handleAction(leave.leaveId, 'reject')}
                      className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded"
                    >
                      Reject
                    </button>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );

  const pendingLeaves = leaves.filter((l) => l.status === 'PENDING');
  const approvedLeaves = leaves.filter((l) => l.status === 'APPROVED');
  const rejectedLeaves = leaves.filter((l) => l.status === 'REJECTED');

return (
  <div className="flex flex-col min-h-screen">
    <Navbar user={true} />

    <div className="flex flex-1 bg-gray-100">
      <ManagerSidebar />

      <div className="flex-1 p-6 lg:p-10 overflow-y-auto">
        <h2 className="text-3xl font-bold text-center text-blue-700 mb-10">
          Manage Leave Requests
        </h2>

        {loading ? (
          <div className="text-center text-gray-500">Loading...</div>
        ) : (
          <div className="space-y-10 max-w-7xl mx-auto">
            {renderTable('Pending Leave Requests', pendingLeaves, true)}
            {renderTable('Approved Leave Requests', approvedLeaves)}
            {renderTable('Rejected Leave Requests', rejectedLeaves)}
          </div>
        )}
      </div>
    </div>
  </div>
);

};

export default LeaveManager;
