import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Navbar from '../components/Navbar';
import ManagerSidebar from './ManagerSidebar';

const EmployeeManager = () => {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedLeaves, setSelectedLeaves] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const token = localStorage.getItem('token');

  const parseJwt = (token) => {
    try {
      return JSON.parse(atob(token.split('.')[1]));
    } catch {
      return null;
    }
  };

  const getManagerDepartmentId = async (username) => {
    try {
      const res = await axios.get('http://localhost:9000/departments/showAllDepartments', {
        headers: { Authorization: `Bearer ${token}` },
      });
      const dept = res.data.find((d) => d.managerName === username);
      return dept?.deptId || null;
    } catch (err) {
      console.error('Error fetching departments:', err);
      return null;
    }
  };

  const fetchEmployees = async (deptId) => {
    try {
      const res = await axios.get(`http://localhost:9000/departments/getEmpByDept/${deptId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const filtered = res.data.filter(
        (emp) => emp.designation.toLowerCase() !== 'manager'
      );
      setEmployees(filtered);
    } catch (err) {
      console.error('Error fetching employees:', err);
    } finally {
      setLoading(false);
    }
  };

  const viewLeaves = async (emp) => {
    try {
      const res = await axios.get(`http://localhost:9000/leave/myLeaves/${emp.empId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setSelectedLeaves(res.data);
      setSelectedEmployee(emp);
      setShowModal(true);
    } catch (err) {
      console.error('Error fetching leaves:', err);
    }
  };

  useEffect(() => {
    const user = parseJwt(token)?.sub;
    if (user) {
      getManagerDepartmentId(user).then((deptId) => {
        if (deptId) fetchEmployees(deptId);
        else setLoading(false);
      });
    } else {
      console.error('Invalid token');
      setLoading(false);
    }
  }, []);

  const statusBadge = (status) => {
    const base = 'px-2 py-1 rounded-full text-xs font-semibold';
    if (status === 'APPROVED') return <span className={`${base} bg-green-100 text-green-700`}>Approved</span>;
    if (status === 'PENDING') return <span className={`${base} bg-yellow-100 text-yellow-700`}>Pending</span>;
    return <span className={`${base} bg-red-100 text-red-700`}>Rejected</span>;
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar user={true} />
      <div className="flex flex-1 overflow-hidden">
        <ManagerSidebar />
        <div className="flex-1 overflow-y-auto bg-gray-100 p-8">
          <h2 className="text-2xl font-semibold text-gray-800 mb-6 text-center">
            Department Employees
          </h2>

          {loading ? (
            <div className="text-center text-gray-500">Loading employees...</div>
          ) : employees.length === 0 ? (
            <div className="text-center text-red-500">No employees found.</div>
          ) : (
            <div className="overflow-x-auto bg-white shadow-md rounded-lg">
              <table className="min-w-full text-sm divide-y divide-gray-200">
                <thead className="bg-gray-200 text-gray-600 uppercase text-xs tracking-wider">
                  <tr>
                    <th className="px-5 py-3 text-left">ID</th>
                    <th className="px-5 py-3 text-left">Name</th>
                    <th className="px-5 py-3 text-left">Email</th>
                    <th className="px-5 py-3 text-left">Phone</th>
                    <th className="px-5 py-3 text-left">Designation</th>
                    <th className="px-5 py-3 text-left">Address</th>
                    <th className="px-5 py-3 text-left">Salary</th>
                    <th className="px-5 py-3 text-left">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 text-gray-700">
                  {employees.map((emp) => (
                    <tr key={emp.empId} className="hover:bg-gray-50">
                      <td className="px-5 py-3 font-mono">{emp.empId}</td>
                      <td className="px-5 py-3">{emp.empName}</td>
                      <td className="px-5 py-3">{emp.email}</td>
                      <td className="px-5 py-3">{emp.phone}</td>
                      <td className="px-5 py-3">{emp.designation}</td>
                      <td className="px-5 py-3">{emp.address}</td>
                      <td className="px-5 py-3">₹{emp.salary}</td>
                      <td className="px-5 py-3">
                        <button
                          onClick={() => viewLeaves(emp)}
                          className="bg-neutral-800 hover:bg-neutral-700 text-white px-4 py-1 rounded transition"
                        >
                          View Leaves
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Modal */}
          {showModal && (
            <div className="fixed inset-0 z-50 bg-black bg-opacity-40 flex items-center justify-center px-4">
              <div className="bg-white w-full max-w-3xl p-6 rounded-xl shadow-lg relative">
                <h3 className="text-xl font-semibold text-gray-800 mb-4">
                  Leave Details – {selectedEmployee?.empName}
                </h3>
                {selectedLeaves.length === 0 ? (
                  <p className="text-gray-500">No leave records available.</p>
                ) : (
                  <div className="overflow-auto">
                    <table className="w-full border text-sm text-gray-700">
                      <thead className="bg-gray-100 border-b text-gray-600">
                        <tr>
                          <th className="px-4 py-2 text-left">Leave ID</th>
                          <th className="px-4 py-2 text-left">Start Date</th>
                          <th className="px-4 py-2 text-left">End Date</th>
                          <th className="px-4 py-2 text-left">Status</th>
                          
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100">
                        {selectedLeaves.map((leave) => (
                          <tr key={leave.leaveId}>
                            <td className="px-4 py-2 font-mono">{leave.leaveId}</td>
                            <td className="px-4 py-2">{leave.startDate}</td>
                            <td className="px-4 py-2">{leave.endDate}</td>
                            <td className="px-4 py-2">{statusBadge(leave.status)}</td>
                           
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
                <div className="mt-6 text-right">
                  <button
                    onClick={() => setShowModal(false)}
                    className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded"
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default EmployeeManager;
