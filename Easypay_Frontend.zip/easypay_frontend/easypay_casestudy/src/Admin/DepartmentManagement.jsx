import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Navbar from '../components/Navbar';
import AdminSidebar from './AdminSidebar';

const DepartmentManagement = () => {
  const [departments, setDepartments] = useState([]);
  const [newDeptName, setNewDeptName] = useState('');
  const [editingDept, setEditingDept] = useState(null);
  const [editDeptName, setEditDeptName] = useState('');

  const token = localStorage.getItem('token');

  const fetchDepartments = async () => {
    try {
      const res = await axios.get('http://localhost:9000/departments/showAllDepartments', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setDepartments(res.data);
    } catch (err) {
      console.error('Error fetching departments:', err);
    }
  };

  const addDepartment = async () => {
    if (!newDeptName.trim()) return alert("Department name cannot be empty");
    try {
      await axios.post(
        'http://localhost:9000/departments/addDepartment',
        { deptName: newDeptName },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setNewDeptName('');
      fetchDepartments();
    } catch (err) {
      console.error('Error adding department:', err);
    }
  };

  const startEdit = (dept) => {
    setEditingDept(dept);
    setEditDeptName(dept.deptName);
  };

  const updateDepartment = async () => {
    try {
      await axios.put(
        `http://localhost:9000/departments/updateDepartment/${editingDept.deptId}`,
        { deptName: editDeptName },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setEditingDept(null);
      fetchDepartments();
    } catch (err) {
      console.error('Error updating department:', err);
    }
  };

  const deleteDepartment = async (id) => {
    if (window.confirm('Are you sure you want to delete this department?')) {
      try {
        await axios.delete(`http://localhost:9000/departments/removeDepartment/${id}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        fetchDepartments();
      } catch (err) {
        console.error('Error deleting department:', err);
      }
    }
  };

  useEffect(() => {
    fetchDepartments();
  }, []);

  return (
    <div className="h-screen flex flex-col">
      <Navbar user={true} />
      <div className="flex flex-1">
        <AdminSidebar />
        <div className="flex-1 p-6 bg-gray-50 overflow-y-auto">
          <h2 className="text-2xl font-bold mb-6">Department Management</h2>

          {/* Add new department */}
          <div className="mb-6 flex items-center gap-4">
            <input
              type="text"
              value={newDeptName}
              onChange={(e) => setNewDeptName(e.target.value)}
              placeholder="Enter department name"
              className="p-2 border rounded w-1/3"
            />
            <button onClick={addDepartment} className="bg-green-600 text-white px-4 py-2 rounded">
              Add Department
            </button>
          </div>

          {/* Department table */}
          <table className="w-full bg-white shadow-md border">
            <thead className="bg-gray-100">
              <tr>
                <th className="p-3 text-left">ID</th>
                <th className="p-3 text-left">Name</th>
                <th className="p-3 text-left">Manager</th>
                <th className="p-3 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {departments.map((dept) => (
                <tr key={dept.deptId} className="border-t">
                  <td className="p-3">{dept.deptId}</td>
                  <td className="p-3">{dept.deptName}</td>
                  <td className="p-3">
                    {dept.managerName ? dept.managerName : <span className="text-gray-400">Not Assigned</span>}
                  </td>
                  <td className="p-3 space-x-2">
                    <button
                      onClick={() => startEdit(dept)}
                      className="bg-blue-600 text-white px-3 py-1 rounded"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => deleteDepartment(dept.deptId)}
                      className="bg-red-600 text-white px-3 py-1 rounded"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* Edit Modal */}
          {editingDept && (
            <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
              <div className="bg-white rounded-lg p-6 w-full max-w-md shadow-lg">
                <h2 className="text-lg font-bold mb-4">Edit Department</h2>
                <input
                  type="text"
                  value={editDeptName}
                  onChange={(e) => setEditDeptName(e.target.value)}
                  className="w-full p-2 border rounded mb-4"
                />
                <div className="flex justify-end space-x-4">
                  <button
                    onClick={() => setEditingDept(null)}
                    className="bg-gray-500 text-white px-4 py-2 rounded"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={updateDepartment}
                    className="bg-green-600 text-white px-4 py-2 rounded"
                  >
                    Save
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DepartmentManagement;
