import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Navbar from '../components/Navbar';
import AdminSidebar from './AdminSidebar';

const LeaveManagement = () => {
  const [leaveData, setLeaveData] = useState({});
  const [filteredLeaveData, setFilteredLeaveData] = useState({});
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState({});
  const leavesPerPage = 5;
  const token = localStorage.getItem('token');

  const fetchLeaves = async () => {
    try {
      const response = await axios.get('http://localhost:9000/leave/viewAllLeaves', {
        headers: { Authorization: `Bearer ${token}` },
      });

      const grouped = {};
      response.data.forEach((leave) => {
        const dept = leave.departmentName || 'Unknown';
        if (!grouped[dept]) grouped[dept] = [];
        grouped[dept].push(leave);
      });

      setLeaveData(grouped);
      setFilteredLeaveData(grouped);

      const initialPages = {};
      Object.keys(grouped).forEach((dept) => (initialPages[dept] = 1));
      setCurrentPage(initialPages);
    } catch (error) {
      console.error('Error fetching leaves:', error);
    }
  };

  const handleSearch = (e) => {
    const value = e.target.value.toLowerCase();
    setSearchTerm(value);

    const filtered = {};
    Object.entries(leaveData).forEach(([dept, leaves]) => {
      const matches = leaves.filter(
        (leave) =>
          dept.toLowerCase().includes(value) ||
          leave.status.toLowerCase().includes(value)
      );
      if (matches.length) filtered[dept] = matches;
    });

    setFilteredLeaveData(filtered);
  };

  const renderStatusBadge = (status) => {
    const colorMap = {
      Approved: 'bg-green-100 text-green-700',
      Pending: 'bg-yellow-100 text-yellow-700',
      Rejected: 'bg-red-100 text-red-700',
    };
    return (
      <span
        className={`px-3 py-1 rounded-full text-xs font-medium ${colorMap[status] || 'bg-gray-100 text-gray-800'}`}
      >
        {status}
      </span>
    );
  };

  const handlePageChange = (dept, direction) => {
    setCurrentPage((prev) => ({
      ...prev,
      [dept]: prev[dept] + direction,
    }));
  };

  useEffect(() => {
    fetchLeaves();
  }, []);

  return (
    <div className="h-screen flex flex-col bg-white">
      <Navbar user={true} />
      <div className="flex flex-1">
        <AdminSidebar />
        <div className="flex-1 px-8 py-6 overflow-y-auto bg-gray-50">
          <h2 className="text-3xl font-semibold text-gray-800 mb-6">Leave Management</h2>

          <input
            type="text"
            value={searchTerm}
            onChange={handleSearch}
            placeholder="Search by department or status..."
            className="mb-6 px-4 py-2 w-full max-w-md border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
          />

          {Object.keys(filteredLeaveData).length === 0 ? (
            <p className="text-gray-600">No matching leave records found.</p>
          ) : (
            Object.entries(filteredLeaveData).map(([dept, leaves]) => {
              const page = currentPage[dept] || 1;
              const start = (page - 1) * leavesPerPage;
              const end = start + leavesPerPage;
              const paginatedLeaves = leaves.slice(start, end);
              const totalPages = Math.ceil(leaves.length / leavesPerPage);

              return (
                <div
                  key={dept}
                  className="bg-white rounded-lg shadow-md p-5 mb-8 border border-gray-200"
                >
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-semibold text-blue-700">{dept} Department</h3>
                    {totalPages > 1 && (
                      <div className="text-sm text-gray-600">
                        Page {page} of {totalPages}
                      </div>
                    )}
                  </div>

                  <div className="overflow-x-auto">
                    <table className="min-w-full text-sm text-left border-collapse">
                      <thead>
                        <tr className="bg-blue-50 text-gray-700 uppercase tracking-wider">
                          <th className="py-3 px-4 border-b">Leave ID</th>
                          <th className="py-3 px-4 border-b">Employee ID</th>
                          <th className="py-3 px-4 border-b">From</th>
                          <th className="py-3 px-4 border-b">To</th>
                          <th className="py-3 px-4 border-b">Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {paginatedLeaves.map((leave, idx) => (
                          <tr
                            key={leave.leaveId}
                            className={idx % 2 === 0 ? 'bg-white' : 'bg-gray-50'}
                          >
                            <td className="py-3 px-4 border-b">{leave.leaveId}</td>
                            <td className="py-3 px-4 border-b">{leave.empId}</td>
                            <td className="py-3 px-4 border-b">{leave.startDate}</td>
                            <td className="py-3 px-4 border-b">{leave.endDate}</td>
                            <td className="py-3 px-4 border-b">
                              {renderStatusBadge(leave.status)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {totalPages > 1 && (
                    <div className="mt-4 flex justify-end gap-2">
                      <button
                        disabled={page === 1}
                        onClick={() => handlePageChange(dept, -1)}
                        className={`px-3 py-1 rounded-md text-sm font-medium ${
                          page === 1
                            ? 'bg-gray-200 text-gray-500 cursor-not-allowed'
                            : 'bg-blue-600 text-white hover:bg-blue-700'
                        }`}
                      >
                        Previous
                      </button>
                      <button
                        disabled={page === totalPages}
                        onClick={() => handlePageChange(dept, 1)}
                        className={`px-3 py-1 rounded-md text-sm font-medium ${
                          page === totalPages
                            ? 'bg-gray-200 text-gray-500 cursor-not-allowed'
                            : 'bg-blue-600 text-white hover:bg-blue-700'
                        }`}
                      >
                        Next
                      </button>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};

export default LeaveManagement;
