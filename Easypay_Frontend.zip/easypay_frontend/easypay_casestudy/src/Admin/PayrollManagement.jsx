import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Navbar from '../components/Navbar';
import AdminSidebar from './AdminSidebar';

const PayrollManagement = () => {
  const [payrolls, setPayrolls] = useState([]);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({
    basicSalary: 0,
    bonuses: 0,
    allowances: 0,
    deductions: 0,
    payDate: '',
    empId: ''
  });
  const [newMode, setNewMode] = useState(false);
  const token = localStorage.getItem('token');

  const fetchAll = async () => {
    try {
      const res = await axios.get('http://localhost:9000/payroll/viewAllPayroll', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setPayrolls(res.data);
    } catch (err) {
      console.error('Fetch payrolls error:', err);
    }
  };

  const fetchCalculatedPayroll = async (empId, payDate) => {
    try {
      const res = await axios.get(`http://localhost:9000/payroll/calculatePayroll/${empId}?payDate=${payDate}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const { basicSalary, bonuses, allowances, deductions } = res.data;
      setForm((prev) => ({
        ...prev,
        basicSalary,
        bonuses,
        allowances,
        deductions
      }));
    } catch (err) {
      console.error('Error fetching calculated payroll:', err);
    }
  };

  const handleChange = async (e) => {
    const { name, value } = e.target;
    const updatedForm = { ...form, [name]: value };
    setForm(updatedForm);

    // Fetch calculated values only when both empId and payDate are present
    if (
      name === 'empId' || name === 'payDate'
    ) {
      const { empId, payDate } = updatedForm;
      if (empId && payDate && newMode) {
        fetchCalculatedPayroll(empId, payDate);
      }
    }
  };

  const openNew = () => {
    setForm({ basicSalary: 0, bonuses: 0, allowances: 0, deductions: 0, payDate: '', empId: '' });
    setNewMode(true);
    setEditing(null);
  };

  const openEdit = (p) => {
    setEditing(p);
    setForm({
      basicSalary: p.basicSalary,
      bonuses: p.bonuses,
      allowances: p.allowances,
      deductions: p.deductions,
      payDate: p.payDate,
      empId: p.empId
    });
    setNewMode(false);
  };

  const submitForm = async () => {
    const url = newMode
      ? 'http://localhost:9000/payroll/addPayroll'
      : `http://localhost:9000/payroll/updatePayroll/${editing.payrollId}`;
    const method = newMode ? axios.post : axios.put;
    try {
      await method(url, form, { headers: { Authorization: `Bearer ${token}` } });
      setNewMode(false);
      setEditing(null);
      fetchAll();
    } catch (err) {
      console.error('Error saving payroll:', err);
    }
  };

  const deletePayroll = async (id) => {
    if (!window.confirm('Are you sure?')) return;
    try {
      await axios.delete(`http://localhost:9000/payroll/deletePayroll/${id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      fetchAll();
    } catch (err) {
      console.error('Delete payroll error:', err);
    }
  };

  useEffect(() => {
    fetchAll();
  }, []);

  return (
    <div className="h-screen flex flex-col">
      <Navbar user={true} />
      <div className="flex flex-1">
        <AdminSidebar />
        <div className="flex-1 p-6 bg-gray-50 overflow-y-auto">
          <h2 className="text-2xl font-bold mb-4">Payroll Management</h2>
          <button
            onClick={openNew}
            className="mb-4 bg-green-600 text-white px-4 py-2 rounded"
          >
            Add New Payroll
          </button>

          <table className="w-full bg-white border shadow">
            <thead className="bg-gray-100">
              <tr>
                <th className="p-3 text-left">ID</th>
                <th className="p-3 text-left">Employee ID</th>
                <th className="p-3 text-left">Pay Date</th>
                <th className="p-3 text-left">Net Salary</th>
                <th className="p-3 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {payrolls.map((p) => (
                <tr key={p.payrollId} className="border-t">
                  <td className="p-3">{p.payrollId}</td>
                  <td className="p-3">{p.empId}</td>
                  <td className="p-3">{p.payDate}</td>
                  <td className="p-3">{p.netSalary}</td>
                  <td className="p-3 space-x-2">
                    <button onClick={() => openEdit(p)} className="bg-blue-600 text-white px-3 py-1 rounded">
                      Edit
                    </button>
                    <button onClick={() => deletePayroll(p.payrollId)} className="bg-red-600 text-white px-3 py-1 rounded">
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {(editing || newMode) && (
            <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
              <div className="bg-white rounded-lg p-6 max-w-lg w-full shadow-lg">
                <h3 className="text-lg font-bold mb-4">
                  {newMode ? 'Add Payroll' : 'Edit Payroll'}
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium">Employee ID</label>
                    <input
                      name="empId"
                      type="number"
                      value={form.empId}
                      onChange={handleChange}
                      className="p-2 border rounded w-full"
                      disabled={!newMode}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium">Pay Date</label>
                    <input
                      name="payDate"
                      type="date"
                      value={form.payDate}
                      onChange={handleChange}
                      className="p-2 border rounded w-full"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium">Basic Salary</label>
                    <input
                      name="basicSalary"
                      type="number"
                      value={form.basicSalary}
                      readOnly
                      className="p-2 border rounded w-full bg-gray-100"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium">Bonuses</label>
                    <input
                      name="bonuses"
                      type="number"
                      value={form.bonuses}
                      readOnly
                      className="p-2 border rounded w-full bg-gray-100"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium">Allowances</label>
                    <input
                      name="allowances"
                      type="number"
                      value={form.allowances}
                      readOnly
                      className="p-2 border rounded w-full bg-gray-100"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium">Deductions</label>
                    <input
                      name="deductions"
                      type="number"
                      value={form.deductions}
                      readOnly
                      className="p-2 border rounded w-full bg-gray-100"
                    />
                  </div>
                </div>
                <div className="mt-4 flex justify-end space-x-4">
                  <button onClick={() => { setEditing(null); setNewMode(false); }} className="bg-gray-500 text-white px-4 py-2 rounded">
                    Cancel
                  </button>
                  <button onClick={submitForm} className="bg-green-600 text-white px-4 py-2 rounded">
                    Save
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PayrollManagement;
