import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Navbar from '../components/Navbar';
import AdminSidebar from './AdminSidebar';

const EmployeeManagement = () => {
  const [employees, setEmployees] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [filteredEmployees, setFilteredEmployees] = useState([]);
  const [editingEmp, setEditingEmp] = useState(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [formData, setFormData] = useState({
    empName: '', email: '', phone: '', address: '',
    designation: '', gender: '', status: '',
    joiningDate: '', salary: '', deptId: ''
  });

  const token = localStorage.getItem('token');

  useEffect(() => {
    fetchEmployees();
    fetchDepartments();
  }, []);

  const fetchEmployees = async () => {
    try {
      const res = await axios.get('http://localhost:9000/employee/viewAllEmployees', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setEmployees(res.data);
      setFilteredEmployees(res.data);
    } catch (err) {
      console.error('Error fetching employees:', err);
    }
  };

  const fetchDepartments = async () => {
    try {
      const res = await axios.get('http://localhost:9000/departments/showAllDepartments', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setDepartments(res.data);
    } catch (err) {
      console.error('Error fetching departments:', err);
    }
  };

  const openAddModal = () => {
    setShowAddModal(true);
    setEditingEmp(null);
    setFormData({
      empName: '', email: '', phone: '', address: '',
      designation: '', gender: '', status: '',
      joiningDate: '', salary: '', deptId: ''
    });
  };

  const startEdit = (emp) => {
    setEditingEmp(emp);
    setShowAddModal(true);
    setFormData({
      empId: emp.empId.toString(),
      empName: emp.empName,
      email: emp.email,
      phone: emp.phone,
      address: emp.address,
      designation: emp.designation,
      gender: emp.gender,
      status: emp.status,
      joiningDate: emp.joiningDate,
      salary: emp.salary,
      deptId: emp.deptId?.toString() || '',
    });
  };

  const handleSearch = (e) => {
    const value = e.target.value.toLowerCase();
    setSearchTerm(value);
    const filtered = employees.filter(emp =>
      emp.empName.toLowerCase().includes(value) ||
      emp.email.toLowerCase().includes(value) ||
      emp.designation.toLowerCase().includes(value) ||
      departments.find(d => d.deptId === emp.deptId)?.deptName.toLowerCase().includes(value)
    );
    setFilteredEmployees(filtered);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
      empId: prev.empId
    }));
  };

  const handleCancel = () => {
    setShowAddModal(false);
    setEditingEmp(null);
  };

  const submitAdd = async () => {
    try {
      await axios.post('http://localhost:9000/employee/addEmployee',
        { ...formData, deptId: parseInt(formData.deptId) },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setShowAddModal(false);
      fetchEmployees();
    } catch (err) {
      console.error('Add failed:', err);
    }
  };

  const submitEdit = async () => {
    try {
      const empIdNum = parseInt(formData.empId);
      const payload = {
        empName: formData.empName,
        email: formData.email,
        salary: formData.salary,
        deptId: parseInt(formData.deptId),
        designation: formData.designation,
        joiningDate: formData.joiningDate,
        status: formData.status
      };

      await axios.put(
        `http://localhost:9000/employee/updateEmployee/${empIdNum}`,
        payload,
        { headers: { Authorization: `Bearer ${token}` } }
      );

      setShowAddModal(false);
      setEditingEmp(null);
      fetchEmployees();
    } catch (err) {
      console.error('Edit failed:', err.response?.data || err.message);
    }
  };

 const deleteEmployee = async (id) => {
  const token = localStorage.getItem('token');
  console.log("Trying to delete employee ID:", id);
  console.log("Token:", token);

  if (window.confirm('Are you sure you want to delete this employee?')) {
    try {
      const response = await axios.delete(
        `http://localhost:9000/employee/removeEmployee/${id}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      console.log("Delete response:", response.data);
      alert("Employee deleted successfully!");
      fetchEmployees(); 
    } catch (err) {
      console.error('Delete failed:', err.response?.data || err.message);
      alert("Delete failed: " + (err.response?.data || err.message));
    }
  }
};



  return (
    <div className="h-screen flex flex-col">
      <Navbar user={true} />
      <div className="flex flex-1">
        <AdminSidebar />
        <div className="flex-1 bg-gray-50 p-6 overflow-y-auto">
          <div className="bg-white shadow-md rounded-lg p-6">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-6">
              <h2 className="text-2xl font-bold text-gray-800">Employee Management</h2>
              <button
                onClick={openAddModal}
                className="bg-green-600 hover:bg-green-700 text-white font-semibold px-5 py-2 rounded-md"
              >
                + Add Employee
              </button>
            </div>

            <input
              type="text"
              value={searchTerm}
              onChange={handleSearch}
              placeholder="Search by name, email, designation, or department"
              className="w-full border border-gray-300 rounded-md px-4 py-2 mb-4 shadow-sm"
            />

            {filteredEmployees.length === 0 ? (
              <p className="text-center text-gray-500 py-4">No matching employees found.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm border border-gray-300 rounded-md">
                  <thead className="bg-gray-200 text-gray-700">
                    <tr>
                      <th className="px-4 py-2 text-left">ID</th>
                      <th className="px-4 py-2 text-left">Name</th>
                      <th className="px-4 py-2 text-left">Email</th>
                      <th className="px-4 py-2 text-left">Designation</th>
                      <th className="px-4 py-2 text-left">Department</th>
                      <th className="px-4 py-2 text-left">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredEmployees.map((emp, idx) => (
                      <tr key={emp.empId} className={idx % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                        <td className="px-4 py-2">{emp.empId}</td>
                        <td className="px-4 py-2">{emp.empName}</td>
                        <td className="px-4 py-2">{emp.email}</td>
                        <td className="px-4 py-2">{emp.designation}</td>
                        <td className="px-4 py-2">
                          {departments.find((d) => d.deptId === emp.deptId)?.deptName || 'N/A'}
                        </td>
                        <td className="px-4 py-2 flex flex-wrap gap-2">
                          <button
                            onClick={() => startEdit(emp)}
                            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-1 rounded-md"
                          >
                            Edit
                          </button>
                          <button
                            onClick={() => deleteEmployee(emp.empId)}
                            className="bg-red-600 hover:bg-red-700 text-white px-4 py-1 rounded-md"
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {showAddModal && (
            <div className="absolute inset-0 flex items-center justify-center z-50 bg-black bg-opacity-20 backdrop-blur-sm">
              <div className="bg-white rounded-lg p-6 w-full max-w-2xl shadow-xl mx-4">
                <h2 className="text-xl font-bold mb-4 text-gray-800">
                  {editingEmp ? 'Edit Employee Details' : 'Add New Employee'}
                </h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {[{ name: 'empName', type: 'text' }, { name: 'email', type: 'text' },
                    { name: 'phone', type: 'text' }, { name: 'address', type: 'text' },
                    { name: 'designation', type: 'text' }, { name: 'salary', type: 'number' }
                  ].map(({ name, type }) => {
                    const editable = ['empName', 'designation', 'salary'];
                    const isDisabled = editingEmp && !editable.includes(name);
                    return (
                      <div key={name}>
                        <label className="block text-sm font-medium text-gray-700 capitalize mb-1">
                          {name}
                        </label>
                        <input
                          name={name}
                          type={type}
                          value={formData[name]}
                          onChange={handleChange}
                          disabled={isDisabled}
                          className={`w-full border ${isDisabled ? 'bg-gray-100 cursor-not-allowed' : 'bg-white'} border-gray-300 rounded px-3 py-2`}
                        />
                      </div>
                    );
                  })}

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Gender</label>
                    <select
                      name="gender"
                      value={formData.gender}
                      onChange={handleChange}
                      className="w-full border border-gray-300 rounded px-3 py-2"
                    >
                      <option value="">-- Select Gender --</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                    <select
                      name="status"
                      value={formData.status}
                      onChange={handleChange}
                      className="w-full border border-gray-300 rounded px-3 py-2"
                    >
                      <option value="">-- Select Status --</option>
                      <option value="Active">Active</option>
                      <option value="Inactive">Inactive</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Joining Date</label>
                    <input
                      type="date"
                      name="joiningDate"
                      value={formData.joiningDate}
                      onChange={handleChange}
                      className="w-full border border-gray-300 rounded px-3 py-2"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Department</label>
                    <select
                      name="deptId"
                      value={formData.deptId}
                      onChange={handleChange}
                      className="w-full border border-gray-300 rounded px-3 py-2"
                    >
                      <option value="">-- Select Department --</option>
                      {departments.map((d) => (
                        <option key={d.deptId} value={d.deptId}>
                          {d.deptName}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="flex justify-end gap-4 mt-6">
                  <button
                    onClick={handleCancel}
                    className="bg-gray-400 hover:bg-gray-500 text-white px-5 py-2 rounded-md"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={editingEmp ? submitEdit : submitAdd}
                    className="bg-green-600 hover:bg-green-700 text-white px-5 py-2 rounded-md"
                  >
                    {editingEmp ? 'Save Changes' : 'Add Employee'}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default EmployeeManagement;
