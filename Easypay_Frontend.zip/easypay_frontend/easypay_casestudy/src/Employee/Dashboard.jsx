import React, { useEffect, useState } from "react";
import axios from "axios";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";
import { saveAs } from "file-saver";
import Navbar from "../components/Navbar";
import EmployeeSidebar from "./EmployeeSidebar";

const COLORS = ["#6366f1", "#10b981", "#f59e0b"];

const Dashboard = () => {
  const [user, setUser] = useState(null);
  const [leaveCount, setLeaveCount] = useState(0);
  const [leaveTypes, setLeaveTypes] = useState({});
  const [payrolls, setPayrolls] = useState([]);
  const [selectedYear, setSelectedYear] = useState("All");
  const [profilePic, setProfilePic] = useState(localStorage.getItem("profilePic"));

  const token = localStorage.getItem("token");

  useEffect(() => {
    const fetchData = async () => {
      if (!token) return;

      try {
        const userRes = await axios.get("http://localhost:9000/employee/viewProfile", {
          headers: { Authorization: `Bearer ${token}` },
        });
        const userData = userRes.data;
        setUser(userData);

        const leaveRes = await axios.get(
          `http://localhost:9000/leave/myLeaves/${userData.empId}`,
          { headers: { Authorization: `Bearer ${token}` } }
        );
        setLeaveCount(leaveRes.data.length);

        const leaveMap = {};
        leaveRes.data.forEach((leave) => {
          leaveMap[leave.leaveType] = (leaveMap[leave.leaveType] || 0) + 1;
        });
        setLeaveTypes(leaveMap);

        const payrollRes = await axios.get(
          `http://localhost:9000/payroll/employeePayroll/${userData.empId}`,
          { headers: { Authorization: `Bearer ${token}` } }
        );
        setPayrolls(payrollRes.data);
      } catch (error) {
        console.error("Dashboard fetch error:", error);
        alert("Error loading dashboard data. Please try again.");
      }
    };

    fetchData();
  }, []);

  const totalPayrolls = payrolls.length;

  const filteredPayrolls =
    selectedYear === "All"
      ? payrolls
      : payrolls.filter(
          (entry) => new Date(entry.payDate).getFullYear().toString() === selectedYear
        );

  const chartData = filteredPayrolls.map((entry) => ({
    month: new Date(entry.payDate).toLocaleDateString("en-IN", {
      month: "short",
      year: "2-digit",
    }),
    salary: entry.netSalary,
  }));

  const uniqueYears = [...new Set(payrolls.map((p) => new Date(p.payDate).getFullYear().toString()))];

  const handleExport = () => {
    const csv = payrolls.map(
      (p) =>
        `${p.payDate},${p.basicSalary},${p.allowances},${p.bonuses},${p.deductions},${p.netSalary}`
    );
    const blob = new Blob(
      ["Pay Date,Basic,Allowance,Bonus,Deduction,Net Salary\n" + csv.join("\n")],
      { type: "text/csv;charset=utf-8;" }
    );
    saveAs(blob, "Payroll_Summary.csv");
  };

  return (
    <div className="flex flex-col h-screen">
      <Navbar user={true} />

      <div className="flex flex-1 overflow-hidden">
        <EmployeeSidebar />

        <div className="flex-1 overflow-y-auto bg-gray-100 p-6">
          <h1 className="text-3xl font-bold text-gray-800 mb-6">Employee Dashboard</h1>

          {user ? (
            <>
              {/* Profile Card */}
              <div className="bg-white p-4 rounded-lg shadow-md flex items-center gap-4 mb-6">
                <img
                  src={
                    profilePic ||
                    "https://wallpapers.com/images/hd/discord-profile-pictures-xk3qyllfj1j46kte.jpg"
                  }
                  alt="Profile"
                  className="w-16 h-16 rounded-full border object-cover"
                />
                <div>
                  <p className="font-semibold text-lg text-gray-700">{user.empName}</p>
                  <p className="text-sm text-gray-500">{user.email}</p>
                  <p className="text-sm text-gray-500">Dept: {user.deptId}</p>
                </div>
              </div>

              {/* Stat Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-6">
                <div className="bg-white p-6 rounded-lg shadow-md text-center">
                  <h2 className="text-sm text-gray-500">Total Leaves</h2>
                  <p className="text-3xl font-bold text-indigo-600">{leaveCount}</p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow-md text-center">
                  <h2 className="text-sm text-gray-500">Payroll Records</h2>
                  <p className="text-3xl font-bold text-green-600">{totalPayrolls}</p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow-md text-center">
                  <h2 className="text-sm text-gray-500 mb-2">Export Payroll</h2>
                  <button
                    onClick={handleExport}
                    className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700"
                  >
                    Download CSV
                  </button>
                </div>
              </div>

              {/* Filter by Year */}
              <div className="mb-4">
                <label className="mr-2 text-sm font-medium text-gray-600">Filter by Year:</label>
                <select
                  className="border rounded px-2 py-1"
                  value={selectedYear}
                  onChange={(e) => setSelectedYear(e.target.value)}
                >
                  <option value="All">All</option>
                  {uniqueYears.map((year) => (
                    <option key={year} value={year}>
                      {year}
                    </option>
                  ))}
                </select>
              </div>

              {/* Charts */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                {/* Payroll Trend */}
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <h2 className="text-lg font-semibold text-gray-700 mb-4">
                    Payroll Trend (Net Salary)
                  </h2>
                  {chartData.length > 0 ? (
                    <ResponsiveContainer width="100%" height={300}>
                      <LineChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip />
                        <Line
                          type="monotone"
                          dataKey="salary"
                          stroke="#6366f1"
                          strokeWidth={2}
                          dot={{ r: 5 }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  ) : (
                    <p className="text-gray-500">No payroll data available for chart.</p>
                  )}
                </div>

                {/* Leave Types Breakdown */}
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <h2 className="text-lg font-semibold text-gray-700 mb-4">
                    Leave Types Breakdown
                  </h2>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={Object.entries(leaveTypes).map(([type, value]) => ({
                          name: type,
                          value,
                        }))}
                        dataKey="value"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        outerRadius={100}
                        label
                      >
                        {Object.entries(leaveTypes).map((_, index) => (
                          <Cell
                            key={`cell-${index}`}
                            fill={COLORS[index % COLORS.length]}
                          />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </>
          ) : (
            <p className="text-center text-gray-500">Loading dashboard...</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
