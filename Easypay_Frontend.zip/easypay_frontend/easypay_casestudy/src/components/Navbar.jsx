import React from "react";
import { Link, useNavigate } from "react-router-dom";

const Navbar = () => {
  const navigate = useNavigate();
  const token = localStorage.getItem("token");

  
  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/login");
  };

  return (
    <nav className="sticky top-0 z-50 bg-white/30 backdrop-blur-lg shadow-md px-4 py-4 flex items-center justify-between w-full">
    
      <div className="flex items-center space-x-2">
        <Link to="/" className="flex items-center space-x-2">
          <img
            src="/logo.png"
            alt="Easypay Logo"
            className="h-10 w-10 object-contain"
          />
          <span className="text-lg font-semibold text-black">Easypay</span>
        </Link>
      </div>

      
      <div className="hidden md:flex items-center space-x-8">
        <Link to="/" className="text-gray-700 hover:text-blue-600 font-medium">
          Home
        </Link>
        <Link to="/about" className="text-gray-700 hover:text-blue-600 font-medium">
          About
        </Link>
        <Link to="/contact" className="text-gray-700 hover:text-blue-600 font-medium">
          Contact
        </Link>
      </div>

     
      <div className="flex items-center space-x-4">
        {token ? (
          <button
            onClick={handleLogout}
            className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-full font-medium transition"
          >
            Logout
          </button>
        ) : (
          <Link
            to="/login"
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-full font-medium transition"
          >
            Login
          </Link>
        )}
      </div>
    </nav>
  );
};

export default Navbar;