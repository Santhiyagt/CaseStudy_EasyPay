import React from 'react';
import Navbar from './Navbar';
const About = () => {
  return (
    <>
      <Navbar />
    
    <section className="relative bg-gradient-to-r from-purple-100 via-blue-100 to-green-100 py-16 px-8 overflow-hidden">
      {/* SVG Pattern Background */}
      <div className="absolute inset-0 w-full h-full -z-10">
        <svg className="w-full h-full" viewBox="0 0 1440 800" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none">
          <defs>
            <pattern id="dots" patternUnits="userSpaceOnUse" width="40" height="40" patternTransform="rotate(45)">
              <circle cx="10" cy="10" r="2" fill="#3B82F6" opacity="0.1" />
            </pattern>
          </defs>
          <rect width="1440" height="800" fill="url(#dots)" />
        </svg>
      </div>

      {/* Content Container */}
      <div className="max-w-7xl mx-auto relative z-20 grid md:grid-cols-2 gap-12 items-center">
        {/* Text Content */}
        <div className="p-8 bg-white bg-opacity-90 rounded-xl shadow-lg backdrop-blur-lg hover:scale-105 transform transition duration-300 ease-in-out">
          <h2 className="text-4xl font-extrabold text-gray-800 mb-4">About Us</h2>
          <p className="text-gray-600 mb-4 text-m">
            <strong>Welcome to EasyPay</strong><br />
            EasyPay Payroll Management System is a comprehensive and secure solution crafted to simplify your organization’s payroll processes. With automation at its core, EasyPay empowers HR and finance teams to efficiently manage employee records, calculate salaries, generate payslips, track leave, and ensure regulatory compliance — all from a single intuitive platform.
          </p>
          <p className="text-gray-600 mb-4 text-m">
            Our mission is to reduce manual workload and eliminate payroll errors by offering a scalable, reliable, and user-friendly system that fits businesses of all sizes. With EasyPay, you gain peace of mind knowing your team will be paid accurately and on time — every time.
          </p>
          <p className="text-gray-600 text-m">
            Trusted by professionals and designed for modern organizations, EasyPay helps you focus more on people and less on paperwork.
          </p>
        </div>

        {/* Image with Overlay & Hover Effect */}
        <div className="relative p-4">
          <div className="absolute inset-0 bg-gradient-to-br from-purple-400 via-blue-400 to-green-400 rounded-xl shadow-lg transform hover:scale-105 transition-transform duration-300"></div>
          <img
            src="https://t4.ftcdn.net/jpg/01/44/20/75/240_F_144207531_KzqS3rsRZaEL2sJ1y5nPe5JYeeP9bVvm.jpg"
            alt="About Us"
            className="relative rounded-xl shadow-xl object-cover w-full h-full hover:opacity-90 transition-opacity duration-300"
          />
        </div>
      </div>
    </section>
    </>
  );
};

export default About;