import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeftIcon } from '@heroicons/react/24/solid';
import Navbar from './Navbar';

const Contact = () => {
  return (
    <>
      <Navbar />
      <div className="max-w-screen-xl mx-auto p-5">
        <div className="grid grid-cols-1 md:grid-cols-12 shadow-lg rounded-lg overflow-hidden">
         
          <div className="bg-indigo-600 md:col-span-4 p-8 text-white flex flex-col justify-between">
            <div>
              <Link to="/" className="hover:text-gray-300 inline-flex items-center">
                <ArrowLeftIcon className="h-5 w-5 mr-1" />
                Back to Home
              </Link>

              <p className="mt-6 text-sm uppercase tracking-wide text-gray-300">Contact Us</p>
              <h2 className="text-3xl font-bold leading-tight mt-2">
                Get in <span className="text-gray-200">Touch</span>
              </h2>
              <p className="mt-4 text-gray-100 leading-relaxed">
                Have questions about payroll, billing, or integration? Reach out to us and our EasyPay support team will respond shortly.
              </p>
            </div>

            <div className="mt-8">
              <p className="text-sm mt-4"><strong>Address:</strong> 123 Payroll Lane, Finance City, India</p>
              <p className="text-sm mt-2"><strong>Phone:</strong> +91 98765 43210</p>
              <p className="text-sm mt-2"><strong>Support:</strong> support@easypay.com</p>
              <p className="text-sm mt-2"><strong>Hours:</strong> Mon – Fri, 9AM – 6PM</p>
            </div>
          </div>

        
          <form className="md:col-span-8 bg-white p-8" onSubmit={(e) => e.preventDefault()}>
            <h3 className="text-xl font-semibold text-gray-800 mb-6">Send Us a Message</h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">First Name</label>
                <input
                  type="text"
                  className="w-full border border-gray-300 rounded-md px-4 py-2 bg-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Last Name</label>
                <input
                  type="text"
                  className="w-full border border-gray-300 rounded-md px-4 py-2 bg-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Phone Number</label>
                <input
                  type="tel"
                  className="w-full border border-gray-300 rounded-md px-4 py-2 bg-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Email Address</label>
                <input
                  type="email"
                  className="w-full border border-gray-300 rounded-md px-4 py-2 bg-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            <div className="mt-6">
              <label className="block text-sm font-semibold text-gray-700 mb-2">Your Message</label>
              <textarea
                rows="5"
                className="w-full border border-gray-300 rounded-md px-4 py-2 bg-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              ></textarea>
            </div>

            <div className="flex items-center justify-between mt-6">
              <label className="flex items-center">
                <input type="checkbox" className="mr-2" />
                <span className="text-sm text-gray-700">Subscribe to newsletter</span>
              </label>

              <button
                type="submit"
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-6 py-2 rounded-md transition duration-200"
              >
                Send Message
              </button>
            </div>
          </form>
        </div>
      </div>
    </>
  );
};

export default Contact;
