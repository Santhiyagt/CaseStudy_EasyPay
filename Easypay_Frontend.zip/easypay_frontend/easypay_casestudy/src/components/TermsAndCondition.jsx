import React from 'react';
import Navbar from './Navbar';

const TermsAndCondition = () => {
  return (
    <>
      <Navbar />
      <div className="bg-gray-50 min-h-screen py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto bg-white p-8 rounded-xl shadow-md">
          <h1 className="text-3xl font-bold text-indigo-600 mb-4">
            Terms & Conditions
          </h1>
          <p className="text-gray-700 mb-4">
            Welcome to <span className="font-semibold">EasyPay</span>. By
            accessing or using our platform, you agree to comply with the
            following terms and conditions.
          </p>

          <div className="mt-6 space-y-6 text-gray-700">
            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-2">
                User Agreement
              </h2>
              <p>
                You must be authorized to use EasyPay within your organization.
                Any misuse of the platform will result in account suspension.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-2">
                Data Accuracy
              </h2>
              <p>
                Users are responsible for ensuring that employee and payroll
                data entered into the system is accurate and up to date.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-2">
                System Usage
              </h2>
              <p>
                EasyPay is to be used solely for managing payroll, leaves,
                departments, and employee profiles in a secure and authorized
                manner.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-2">
                Policy Changes
              </h2>
              <p>
                We reserve the right to modify these terms at any time. Updates
                will be communicated through the platform.
              </p>
            </section>
          </div>

          <div className="mt-8">
            <p className="text-gray-600 text-sm">
              If you have questions about our terms, please{' '}
              <a
                href="/contact"
                className="text-indigo-600 hover:underline font-medium"
              >
                contact our support team
              </a>
              .
            </p>
          </div>
        </div>
      </div>
    </>
  );
};

export default TermsAndCondition;
