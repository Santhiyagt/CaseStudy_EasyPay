import React from 'react';
import Navbar from './Navbar';

const PrivacyPolicy = () => {
  return (
    <>
      <Navbar />
      <div className="bg-gray-50 min-h-screen py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto bg-white p-8 rounded-xl shadow-md">
          <h1 className="text-3xl font-bold text-indigo-600 mb-4">
            Privacy Policy
          </h1>
          <p className="text-gray-700 mb-4">
            At <span className="font-semibold">EasyPay</span>, we are committed
            to safeguarding your privacy and protecting your personal
            information.
          </p>

          <div className="mt-6 space-y-6 text-gray-700">
            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-2">
                Information We Collect
              </h2>
              <p>
                We collect only the necessary details such as employee records,
                payroll data, and contact information to offer our services
                efficiently.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-2">
                How We Use It
              </h2>
              <p>
                Your data is used solely to process payrolls, manage leaves, and
                generate insightful reports for your organization.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-2">
                Data Protection
              </h2>
              <p>
                We implement robust security measures to ensure that your data
                is stored securely and used only for authorized purposes.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-2">
                Your Rights
              </h2>
              <p>
                You have full control over your data. You may request access,
                correction, or deletion at any time.
              </p>
            </section>
          </div>

          <div className="mt-8">
            <p className="text-gray-600 text-sm">
              For further inquiries, feel free to{' '}
              <a
                href="/contact"
                className="text-indigo-600 hover:underline font-medium"
              >
                contact us
              </a>
              .
            </p>
          </div>
        </div>
      </div>
    </>
  );
};

export default PrivacyPolicy;
