
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

const token = localStorage.getItem('token');
const parseJwt = (token) => {
  try {
    return JSON.parse(atob(token.split('.')[1]));
  } catch {
    return null;
  }
};

export const fetchManagerStats = createAsyncThunk(
  
  'managerStats/fetch',
  async (_, { rejectWithValue }) => {
    try {
      const username = parseJwt(token)?.sub;

      const deptRes = await axios.get('http://localhost:9000/departments/showAllDepartments', {
        headers: { Authorization: `Bearer ${token}` },
      });

      const dept = deptRes.data.find((d) => d.managerName === username);
      if (!dept) return rejectWithValue('No department assigned');

      const empRes = await axios.get(`http://localhost:9000/departments/getEmpByDept/${dept.deptId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      const employees = empRes.data.filter((e) => e.designation.toLowerCase() !== 'manager');

      const leaveStats = await Promise.all(
        employees.map(async (emp) => {
          const leaveRes = await axios.get(`http://localhost:9000/leave/myLeaves/${emp.empId}`, {
            headers: { Authorization: `Bearer ${token}` },
          });

          return {
            empName: emp.empName,
            leaveCount: leaveRes.data.length,
            leaveDates: leaveRes.data.map(leave => leave.startDate),
          };
        })
      );

      return {
        totalEmployees: employees.length,
        leaveStats,
      };
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

const managerStatsSlice = createSlice({
  name: 'managerStats',
  initialState: {
    totalEmployees: 0,
    leaveStats: [],
    loading: false,
    error: null,
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchManagerStats.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchManagerStats.fulfilled, (state, action) => {
        state.loading = false;
        state.totalEmployees = action.payload.totalEmployees;
        state.leaveStats = action.payload.leaveStats;
      })
      .addCase(fetchManagerStats.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export default managerStatsSlice.reducer;
