package com.hexaware.easypay.mapper;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hexaware.easypay.dto.LeaveDTO;
import com.hexaware.easypay.entity.Leaves;

@Component
public class LeaveMapper {

    @Autowired
    private ModelMapper modelMapper;

    public Leaves dtoToLeave(LeaveDTO dto)
    {
        return modelMapper.map(dto, Leaves.class);
    }

    public LeaveDTO leaveToDto(Leaves entity) {
        LeaveDTO dto = modelMapper.map(entity, LeaveDTO.class);

        if (entity.getEmployee() != null) {
            dto.setEmpId(entity.getEmployee().getEmpId());
            
            if (entity.getEmployee().getDepartment() != null) {
                dto.setDepartmentName(entity.getEmployee().getDepartment().getDeptName());
            }
        }

        return dto;
    }

}