package com.hexaware.easypay.exception;

public class DuplicateRecordException extends RuntimeException 
{
    public DuplicateRecordException(String message) 
    {
        super(message);
    }
}
