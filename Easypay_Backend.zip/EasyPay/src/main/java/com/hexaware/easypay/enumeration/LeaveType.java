package com.hexaware.easypay.enumeration;

public enum LeaveType
{
    CASUAL,
    SICK,
    EARNED
}