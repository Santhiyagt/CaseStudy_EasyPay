package com.hexaware.easypay.dto;

public class DepartmentDTO {

    private int deptId;
    private String deptName;
    private String managerName; 

    public DepartmentDTO() {
    }

    public DepartmentDTO(int deptId, String deptName) {
        this.deptId = deptId;
        this.deptName = deptName;
    }


    public DepartmentDTO(int deptId, String deptName, String managerName) {
        this.deptId = deptId;
        this.deptName = deptName;
        this.managerName = managerName;
    }

    public int getDeptId() {
        return deptId;
    }

    public void setDeptId(int deptId) {
        this.deptId = deptId;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public String getManagerName() {
        return managerName;
    }

    public void setManagerName(String managerName) {
        this.managerName = managerName;
    }

    @Override
    public String toString() {
        return "DepartmentDTO [deptId=" + deptId + ", deptName=" + deptName + ", managerName=" + managerName + "]";
    }
}
