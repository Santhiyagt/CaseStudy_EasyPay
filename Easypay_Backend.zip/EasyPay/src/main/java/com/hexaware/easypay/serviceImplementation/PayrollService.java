package com.hexaware.easypay.serviceImplementation;

import com.hexaware.easypay.dto.PayrollDTO;
import com.hexaware.easypay.entity.Employee;
import com.hexaware.easypay.entity.Leaves;
import com.hexaware.easypay.entity.Payroll;
import com.hexaware.easypay.enumeration.LeaveStatus;
import com.hexaware.easypay.exception.ResourceNotFoundException;
import com.hexaware.easypay.mapper.PayrollMapper;
import com.hexaware.easypay.repository.EmployeeRepository;
import com.hexaware.easypay.repository.LeaveRepository;
import com.hexaware.easypay.repository.PayrollRepository;
import com.hexaware.easypay.serviceInterface.IPayrollService;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

@Service
public class PayrollService implements IPayrollService {

    @Autowired
    private PayrollRepository payrollRepo;

    @Autowired
    private EmployeeRepository employeeRepo;

    @Autowired
    private LeaveRepository leaveRepo;

    @Autowired
    private PayrollMapper payrollMapper;

    @Override
    public PayrollDTO addPayroll(PayrollDTO dto) {
        if (dto == null) {
            throw new IllegalArgumentException("PayrollDTO cannot be null");
        }

        Employee employee = employeeRepo.findById(dto.getEmpId())
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found with id: " + dto.getEmpId()));

        Payroll payroll = payrollMapper.dtoToPayroll(dto);
        payroll.setEmployee(employee);

        double netSalary = payroll.getBasicSalary() + payroll.getBonuses() + payroll.getAllowances() - payroll.getDeductions();
        payroll.setNetSalary(netSalary);

        Payroll saved = payrollRepo.save(payroll);
        return payrollMapper.PayrollToDto(saved);
    }

    @Override
    public PayrollDTO getPayrollById(int id) {
        Payroll payroll = payrollRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll not found with id: " + id));
        return payrollMapper.PayrollToDto(payroll);
    }

    @Override
    public List<PayrollDTO> getAllPayrolls() {
        List<Payroll> payrolls = payrollRepo.findAll();
        List<PayrollDTO> payrollDTOs = new ArrayList<>();
        for (Payroll payroll : payrolls) {
            PayrollDTO dto = payrollMapper.PayrollToDto(payroll);
            payrollDTOs.add(dto);
        }
        return payrollDTOs;
    }

    @Override
    public PayrollDTO updatePayroll(int id, PayrollDTO dto) {
        Payroll payroll = payrollRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll not found with id: " + id));

        payroll.setBasicSalary(dto.getBasicSalary());
        payroll.setBonuses(dto.getBonuses());
        payroll.setAllowances(dto.getAllowances());
        payroll.setDeductions(dto.getDeductions());
        payroll.setPayDate(dto.getPayDate());

        double netSalary = dto.getBasicSalary() + dto.getBonuses() + dto.getAllowances() - dto.getDeductions();
        payroll.setNetSalary(netSalary);

        Payroll updatedPayroll = payrollRepo.save(payroll);
        return payrollMapper.PayrollToDto(updatedPayroll);
    }

    @Override
    public String deletePayroll(int id) {
        Payroll payroll = payrollRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll not found with id: " + id));
        payrollRepo.delete(payroll);
        return "Payroll with ID " + id + " deleted successfully.";
    }

    @Override
    public List<PayrollDTO> getPayrollsByEmployeeId(int employeeId) {
        List<Payroll> payrolls = payrollRepo.findByEmployeeEmpId(employeeId);
        List<PayrollDTO> payrollDTOs = new ArrayList<>();

        for (Payroll payroll : payrolls) {
            PayrollDTO dto = payrollMapper.PayrollToDto(payroll);
            payrollDTOs.add(dto);
        }
        return payrollDTOs;
    }

    @Override
    public PayrollDTO calculatePayrollForEmployee(int empId, Date payDate) {
        Employee employee = employeeRepo.findById(empId)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found with ID: " + empId));

        double basicSalary = employee.getSalary();
        double bonuses = 0;
        double allowances = 0;
        double deductions = 0;

        // Assign department-based bonuses and allowances
        String deptName = employee.getDepartment().getDeptName();
        if (deptName.equalsIgnoreCase("IT")) {
            bonuses = 2000;
            allowances = 1000;
        } else if (deptName.equalsIgnoreCase("Analytics")) {
            bonuses = 2500;
            allowances = 1500;
        } else {
            bonuses = 1000;
            allowances = 800;
        }

        List<Leaves> approvedLeaves = leaveRepo.findByEmployeeEmpId(empId).stream()
        	    .filter(l -> l.getStatus() == LeaveStatus.APPROVED)
        	    .filter(l -> {
        	        LocalDate start = LocalDate.parse(l.getStartDate());
        	        return start.getMonth() == payDate.toLocalDate().getMonth()
        	            && start.getYear() == payDate.toLocalDate().getYear();
        	    })
        	    .toList();

        	long totalLeaveDays = 0;
        	for (Leaves l : approvedLeaves) {
        	    LocalDate start = LocalDate.parse(l.getStartDate());
        	    LocalDate end = LocalDate.parse(l.getEndDate());
        	    long days = ChronoUnit.DAYS.between(start, end) + 1;
        	    totalLeaveDays += days;
        	}

        deductions = totalLeaveDays * (basicSalary / 30.0); 

        PayrollDTO dto = new PayrollDTO();
        dto.setEmpId(empId);
        dto.setPayDate(payDate);
        dto.setBasicSalary(basicSalary);
        dto.setBonuses(bonuses);
        dto.setAllowances(allowances);
        dto.setDeductions(deductions);

        return dto;
    }
}
