package com.hexaware.easypay.dto;

public class EmployeeDTO 
{

	private int empId;
    private String empName;
    private String email;
    private String phone;
    private String address;
    private String designation;
    private String gender;
    private String status;
    private String joiningDate;
    private int deptId;
    private Double salary;
    private String deptName;

  
    

    public EmployeeDTO() {}

    public EmployeeDTO(int empId, String empName, String email, String phone, String address,
                       String designation, String gender, String status, String joiningDate,
                       int deptId, Double salary, String deptName) {
        this.empId = empId;
        this.empName = empName;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.designation = designation;
        this.gender = gender;
        this.status = status;
        this.joiningDate = joiningDate;
        this.deptId = deptId;
        this.salary = salary;
        this.deptName = deptName;
    }

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getJoiningDate() {
		return joiningDate;
	}

	public void setJoiningDate(String joiningDate) {
		this.joiningDate = joiningDate;
	}

	public int getDeptId() {
		return deptId;
	}

	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
    
    
    
}