package com.hexaware.easypay.serviceInterface;

import java.util.List;

import com.hexaware.easypay.dto.EmployeeDTO;

public interface IEmployeeService {
    List<EmployeeDTO> getAllEmployees();
    EmployeeDTO getEmployeeById(int id);
    String addEmployee(EmployeeDTO dto);
    String updateEmployee(int empId,EmployeeDTO dto);
    String updateOwnProfile(int empId, EmployeeDTO dto);
    String deleteEmployee(int id);
    EmployeeDTO getEmployeeByUsername(String empName);
}