package com.hexaware.easypay.controller;

import com.hexaware.easypay.dto.PayrollDTO;
import com.hexaware.easypay.repository.PayrollRepository;
import com.hexaware.easypay.serviceImplementation.PayrollService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.util.List;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/payroll")
public class PayrollController {

    @Autowired
    private PayrollService payrollService;
    
    @Autowired
    private PayrollRepository payrollRepo;

    @PostMapping("/addPayroll")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<PayrollDTO> createPayroll(@RequestBody PayrollDTO payroll) {
        return new ResponseEntity<>(payrollService.addPayroll(payroll), HttpStatus.CREATED);
    }

    @GetMapping("/viewAllPayroll")
    @PreAuthorize("hasAnyRole('ADMIN', 'MANAGER')")
    public ResponseEntity<List<PayrollDTO>> getAllPayrolls() {
        List<PayrollDTO> payrolls = payrollService.getAllPayrolls();
        return new ResponseEntity<>(payrolls, HttpStatus.OK);
    }

    @GetMapping("/viewPayroll/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<PayrollDTO> getPayrollById(@PathVariable int id) {
        PayrollDTO payroll = payrollService.getPayrollById(id);
        return ResponseEntity.ok(payroll);
    }

    @PutMapping("/updatePayroll/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<PayrollDTO> updatePayroll(@PathVariable int id, @RequestBody PayrollDTO pay) {
        return new ResponseEntity<>(payrollService.updatePayroll(id, pay), HttpStatus.OK);
    }

    @DeleteMapping("/deletePayroll/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<String> deletePayroll(@PathVariable int id) {
        String result = payrollService.deletePayroll(id);
        return new ResponseEntity<>(result, HttpStatus.OK);
    }

    @GetMapping("/employeePayroll/{employeeId}")
    @PreAuthorize("hasAnyRole('ADMIN', 'MANAGER', 'EMPLOYEE')")
    public ResponseEntity<List<PayrollDTO>> getPayrollsByEmployeeId(@PathVariable int employeeId) {
        List<PayrollDTO> payrolls = payrollService.getPayrollsByEmployeeId(employeeId);
        return new ResponseEntity<>(payrolls, HttpStatus.OK);
    }

    @GetMapping("/calculatePayroll/{empId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<PayrollDTO> calculatePayroll(@PathVariable int empId, @RequestParam("payDate") Date payDate) {
        PayrollDTO dto = payrollService.calculatePayrollForEmployee(empId, payDate);
        return new ResponseEntity<>(dto, HttpStatus.OK);
    }
    
    @GetMapping("/count")
    public long getPayrollCount() {
        return payrollRepo.count();
    }
}
